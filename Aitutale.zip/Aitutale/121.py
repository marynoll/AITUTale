import pygame
import sys

pygame.init()

# --- Внутреннее разрешение (пиксель-арт) ---
WIDTH, HEIGHT = 320, 240
SCALE = 3  # окно будет 960x720

screen_surface = pygame.Surface((WIDTH, HEIGHT))
screen = pygame.display.set_mode((WIDTH * SCALE, HEIGHT * SCALE))
pygame.display.set_caption("AITUTALE")
clock = pygame.time.Clock()

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
AUTUMN_YELLOW = (204, 153, 51)

font = pygame.font.Font("determination.ttf", 8)

# --- ДАННЫЕ ПЕРСОНАЖА ---
player_name = "Frisk"
player_lv = 1
player_hp = 20
player_max_hp = 20
show_menu = False

# --- ЗАГРУЗКА ЛОГОТИПА ---
title_image = pygame.image.load('title.png').convert()
title_image = pygame.transform.scale(title_image, (200, 40))
title_x = (WIDTH - 200) // 2
title_y = (HEIGHT - 40) // 2

# --- ЗАГРУЗКА СЛОЁВ (улица) ---
def load_layer(filename):
    return pygame.image.load(filename).convert_alpha()

layer_granitsa = load_layer('granitsa.png')
layer_kurilka  = load_layer('kurilka.png')
layer_doors    = load_layer('doors.png')
layer_budka    = load_layer('kurilka-budka.png')
layer_campus   = load_layer('campus_colisia.png')
layer_way      = load_layer('way.png')

map_rect = layer_granitsa.get_rect()

# --- ЗАГРУЗКА АТРИУМА ---
layer_atrium         = load_layer('atrium.png')
layer_atrium_colisia = load_layer('COLISIAFORATRIUM.png')
atrium_rect          = layer_atrium.get_rect()
mask_atrium_col      = pygame.mask.from_surface(layer_atrium_colisia)

# --- ДАННЫЕ ИСТОРИИ ---
slides = [
    "Фриск упала в гору НО она попала\nне в подземелье а в шарагу\nАстаны Айту.",
    "Не понимая чо происходит она\nпытается уйти куда нибудь но\nтам везде стройка препятствия.",
    "Ей остается только зайти туда\nв АЙту."
]
current_slide = 0
char_index = 0
text_speed = 50

# --- СОСТОЯНИЯ ---
STATE_TITLE      = "TITLE"
STATE_STORY      = "STORY"
STATE_GAME       = "GAME"
STATE_DOOR       = "DOOR"
STATE_TRANSITION = "TRANSITION"
STATE_ATRIUM     = "ATRIUM"
current_state = STATE_TITLE

start_time = pygame.time.get_ticks()
last_tick = start_time

# --- ДИАЛОГ ДВЕРИ ---
door_choice = 0
door_zone = pygame.Rect(390, 36, 30, 20)  # подбери под свою карту

# --- ПЕРЕХОД (fade) ---
BLACK_DURATION = 400   # мс — чёрный экран
FADEIN_DURATION= 1000  # мс — появление
transition_start = 0
transition_phase = "black"
next_state_after_transition = STATE_ATRIUM

fade_surface = pygame.Surface((WIDTH, HEIGHT))
fade_surface.fill(BLACK)

# === АНИМАЦИЯ ===
class SpriteSheet:
    def __init__(self, filename):
        self.sheet = pygame.image.load(filename).convert_alpha()
        bg_color = self.sheet.get_at((0, 0))
        self.sheet.set_colorkey(bg_color)

    def get_image(self, x, y, width, height, scale_w, scale_h):
        image = self.sheet.subsurface(pygame.Rect(x, y, width, height))
        return pygame.transform.scale(image, (scale_w, scale_h))

sheet = SpriteSheet('walking_sheet.png')
sheet_width  = sheet.sheet.get_width()
FRAME_WIDTH  = sheet_width // 8
FRAME_HEIGHT = sheet.sheet.get_height()
SCALE_W, SCALE_H = FRAME_WIDTH, FRAME_HEIGHT

# --- МАСКА ИГРОКА ---
player_surf_mask = pygame.Surface((SCALE_W, SCALE_H), pygame.SRCALPHA)
player_surf_mask.fill((255, 255, 255, 255))
player_mask = pygame.mask.from_surface(player_surf_mask)

# --- МАСКИ КОЛЛИЗИИ (улица) ---
mask_granitsa   = pygame.mask.from_surface(layer_granitsa)
mask_campus     = pygame.mask.from_surface(layer_campus)
collision_masks = [mask_granitsa, mask_campus]

walk_down  = [sheet.get_image(0*FRAME_WIDTH, 0, FRAME_WIDTH, FRAME_HEIGHT, SCALE_W, SCALE_H),
              sheet.get_image(1*FRAME_WIDTH, 0, FRAME_WIDTH, FRAME_HEIGHT, SCALE_W, SCALE_H)]
walk_up    = [sheet.get_image(2*FRAME_WIDTH, 0, FRAME_WIDTH, FRAME_HEIGHT, SCALE_W, SCALE_H),
              sheet.get_image(3*FRAME_WIDTH, 0, FRAME_WIDTH, FRAME_HEIGHT, SCALE_W, SCALE_H)]
walk_right = [sheet.get_image(6.175*FRAME_WIDTH, 0, FRAME_WIDTH, FRAME_HEIGHT, SCALE_W, SCALE_H),
              sheet.get_image(7.175*FRAME_WIDTH, 0, FRAME_WIDTH, FRAME_HEIGHT, SCALE_W, SCALE_H)]
walk_left  = [pygame.transform.flip(img, True, False) for img in walk_right]

#
# --- ИГРОК ---
player_rect    = pygame.Rect(map_rect.width//2, map_rect.height//2, SCALE_W, SCALE_H)
player_speed   = 2
current_frame  = 0
is_moving      = False
animation_speed = 150
last_anim_tick = pygame.time.get_ticks()
current_anim   = walk_down

camera_x    = 0
camera_y    = 0
atrium_cam_x = 0
atrium_cam_y = 0

# --- ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ---
def draw_world():
    cx, cy = -camera_x, -camera_y
    screen_surface.blit(layer_granitsa, (cx, cy))
    screen_surface.blit(layer_way,      (cx, cy))
    screen_surface.blit(layer_doors,    (cx, cy))
    screen_surface.blit(current_anim[current_frame],
                        (player_rect.x - camera_x, player_rect.y - camera_y))
    screen_surface.blit(layer_kurilka,  (cx, cy))
    screen_surface.blit(layer_budka,    (cx, cy))
    screen_surface.blit(layer_campus,   (cx, cy))

def draw_atrium():
    cx, cy = -atrium_cam_x, -atrium_cam_y
    screen_surface.blit(layer_atrium, (cx, cy))
    screen_surface.blit(current_anim[current_frame],
                        (player_rect.x - atrium_cam_x, player_rect.y - atrium_cam_y))

def start_transition(next_state):
    global transition_start, transition_phase, next_state_after_transition, current_state
    transition_start = pygame.time.get_ticks()
    transition_phase = "black"
    next_state_after_transition = next_state
    current_state = STATE_TRANSITION

# --- ГЛАВНЫЙ ЦИКЛ ---
while True:
    screen_surface.fill(BLACK)
    current_time = pygame.time.get_ticks()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        # --- ДВЕРЬ ---
        elif event.type == pygame.KEYDOWN and current_state == STATE_DOOR:
            if event.key == pygame.K_LEFT:
                door_choice = 0
            elif event.key == pygame.K_RIGHT:
                door_choice = 1
            elif event.key in (pygame.K_RETURN, pygame.K_z):
                if door_choice == 0:
                    # Ставим игрока в атриум внизу по центру
                    player_rect.x = atrium_rect.width // 2
                    player_rect.y = atrium_rect.height - SCALE_H - 10
                    start_transition(STATE_ATRIUM)
                else:
                    current_state = STATE_GAME
                door_choice = 0
            elif event.key == pygame.K_ESCAPE:
                current_state = STATE_GAME
                door_choice = 0

        # --- ИГРА ---
        elif event.type == pygame.KEYDOWN and current_state == STATE_GAME:
            if event.key in (pygame.K_LCTRL, pygame.K_RCTRL):
                show_menu = not show_menu
            elif event.key == pygame.K_RETURN:
                if door_zone.colliderect(player_rect):
                    current_state = STATE_DOOR
                    door_choice = 0

        # --- АТРИУМ ---
        elif event.type == pygame.KEYDOWN and current_state == STATE_ATRIUM:
            if event.key in (pygame.K_LCTRL, pygame.K_RCTRL):
                show_menu = not show_menu

        # --- ИСТОРИЯ ---
        elif event.type == pygame.KEYDOWN and current_state == STATE_STORY:
            if event.key in (pygame.K_SPACE, pygame.K_RETURN):
                if char_index < len(slides[current_slide]):
                    char_index = len(slides[current_slide])
                else:
                    current_slide += 1
                    char_index = 0
                    if current_slide >= len(slides):
                        current_state = STATE_GAME

    # --- ЛОГИКА УЛИЦЫ ---
    if current_state == STATE_GAME:
        keys = pygame.key.get_pressed()
        is_moving = False
        old_anim = current_anim
        old_x, old_y = player_rect.x, player_rect.y

        if keys[pygame.K_LEFT] and player_rect.left > 0:
            player_rect.x -= player_speed
            current_anim = walk_left
            is_moving = True
        elif keys[pygame.K_RIGHT] and player_rect.right < map_rect.width:
            player_rect.x += player_speed
            current_anim = walk_right
            is_moving = True
        if keys[pygame.K_UP] and player_rect.top > 0:
            player_rect.y -= player_speed
            current_anim = walk_up
            is_moving = True
        elif keys[pygame.K_DOWN] and player_rect.bottom < map_rect.height:
            player_rect.y += player_speed
            current_anim = walk_down
            is_moving = True

        for col_mask in collision_masks:
            if col_mask.overlap(player_mask, (player_rect.x, player_rect.y)):
                player_rect.x = old_x
                player_rect.y = old_y
                is_moving = False
                break


        if old_anim != current_anim:
            current_frame = 0
        if is_moving:
            if current_time - last_anim_tick > animation_speed:
                current_frame = (current_frame + 1) % len(current_anim)
                last_anim_tick = current_time
        else:
            current_frame = 0

        camera_x = player_rect.centerx - WIDTH // 2
        camera_y = player_rect.centery - HEIGHT // 2
        camera_x = max(0, min(camera_x, max(0, map_rect.width - WIDTH)))
        camera_y = max(0, min(camera_y, max(0, map_rect.height - HEIGHT)))

    # --- ЛОГИКА АТРИУМА ---
    elif current_state == STATE_ATRIUM:
        keys = pygame.key.get_pressed()
        is_moving = False
        old_anim = current_anim
        old_x, old_y = player_rect.x, player_rect.y

        if keys[pygame.K_LEFT] and player_rect.left > 0:
            player_rect.x -= player_speed
            current_anim = walk_left
            is_moving = True
        elif keys[pygame.K_RIGHT] and player_rect.right < atrium_rect.width:
            player_rect.x += player_speed
            current_anim = walk_right
            is_moving = True
        if keys[pygame.K_UP] and player_rect.top > 0:
            player_rect.y -= player_speed
            current_anim = walk_up
            is_moving = True
        elif keys[pygame.K_DOWN] and player_rect.bottom < atrium_rect.height:
            player_rect.y += player_speed
            current_anim = walk_down
            is_moving = True

        if mask_atrium_col.overlap(player_mask, (player_rect.x, player_rect.y)):
            player_rect.x = old_x
            player_rect.y = old_y
            is_moving = False

        if old_anim != current_anim:
            current_frame = 0
        if is_moving:
            if current_time - last_anim_tick > animation_speed:
                current_frame = (current_frame + 1) % len(current_anim)
                last_anim_tick = current_time
        else:
            current_frame = 0

        atrium_cam_x = player_rect.centerx - WIDTH // 2
        atrium_cam_y = player_rect.centery - HEIGHT // 2
        atrium_cam_x = max(0, min(atrium_cam_x, max(0, atrium_rect.width - WIDTH)))
        atrium_cam_y = max(0, min(atrium_cam_y, max(0, atrium_rect.height - HEIGHT)))

    # --- ОТРИСОВКА ---
    if current_state == STATE_TITLE:
        screen_surface.blit(title_image, (title_x, title_y))
        if current_time - start_time > 4000:
            current_state = STATE_STORY
            last_tick = current_time

    elif current_state == STATE_STORY:
        pygame.draw.rect(screen_surface, AUTUMN_YELLOW, (10, 10, 300, 150))
        if current_time - last_tick > text_speed:
            if char_index < len(slides[current_slide]):
                char_index += 1
            last_tick = current_time
        current_text = slides[current_slide][:char_index]
        for i, line in enumerate(current_text.split('\n')):
            screen_surface.blit(font.render(line, True, WHITE), (15, 170 + i * 12))

    elif current_state == STATE_GAME:
        draw_world()
        if door_zone.colliderect(player_rect):
            hint = font.render("ENTER — войти", True, AUTUMN_YELLOW)
            screen_surface.blit(hint, (WIDTH//2 - hint.get_width()//2, 160))
        if show_menu:
            box1 = pygame.Rect(4, 4, 80, 46)
            pygame.draw.rect(screen_surface, BLACK, box1)
            pygame.draw.rect(screen_surface, WHITE, box1, 2)
            screen_surface.blit(font.render(player_name, True, WHITE),                       (box1.x+4, box1.y+4))
            screen_surface.blit(font.render(f"LV {player_lv}", True, WHITE),                 (box1.x+4, box1.y+16))
            screen_surface.blit(font.render(f"HP {player_hp}/{player_max_hp}", True, WHITE), (box1.x+4, box1.y+28))
            box2 = pygame.Rect(4, 54, 80, 30)
            pygame.draw.rect(screen_surface, BLACK, box2)
            pygame.draw.rect(screen_surface, WHITE, box2, 2)
            screen_surface.blit(font.render("\u2665 ITEM", True, (255, 60, 60)), (box2.x+4, box2.y+4))
            screen_surface.blit(font.render("  STAT", True, WHITE),              (box2.x+4, box2.y+16))

    elif current_state == STATE_DOOR:
        draw_world()
        box = pygame.Rect(10, 175, 300, 55)
        pygame.draw.rect(screen_surface, BLACK, box)
        pygame.draw.rect(screen_surface, WHITE, box, 2)
        screen_surface.blit(font.render("Хотите войти?", True, WHITE), (18, 182))
        da_color  = AUTUMN_YELLOW if door_choice == 0 else WHITE
        net_color = AUTUMN_YELLOW if door_choice == 1 else WHITE
        screen_surface.blit(font.render("* Да"  if door_choice == 0 else "  Да",  True, da_color),  (80,  205))
        screen_surface.blit(font.render("* Нет" if door_choice == 1 else "  Нет", True, net_color), (180, 205))

    elif current_state == STATE_ATRIUM:
        draw_atrium()

    elif current_state == STATE_TRANSITION:
        elapsed = current_time - transition_start

        if transition_phase == "black":
            screen_surface.fill(BLACK)
            if elapsed >= BLACK_DURATION:
                transition_phase = "fadein"
                transition_start = current_time

        elif transition_phase == "fadein":
            # Обновляем камеру атриума
            atrium_cam_x = player_rect.centerx - WIDTH // 2
            atrium_cam_y = player_rect.centery - HEIGHT // 2
            atrium_cam_x = max(0, min(atrium_cam_x, max(0, atrium_rect.width - WIDTH)))
            atrium_cam_y = max(0, min(atrium_cam_y, max(0, atrium_rect.height - HEIGHT)))
            
            draw_atrium()
            alpha = max(0, 255 - int(255 * elapsed / FADEIN_DURATION))
            fade_surface.set_alpha(alpha)
            screen_surface.blit(fade_surface, (0, 0))
            if elapsed >= FADEIN_DURATION:
                current_state = next_state_after_transition

    # Растягиваем 320x240 → на окно
    scaled = pygame.transform.scale(screen_surface, (WIDTH * SCALE, HEIGHT * SCALE))
    screen.blit(scaled, (0, 0))

    pygame.display.flip()
    clock.tick(60)